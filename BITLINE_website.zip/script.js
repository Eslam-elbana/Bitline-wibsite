// JS للموقع
console.log('BIT LINE website loaded');